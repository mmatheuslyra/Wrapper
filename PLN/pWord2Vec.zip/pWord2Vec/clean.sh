#!/bin/bash

#clean up workspace
rm -rf pWord2Vec pWord2Vec_mpi hyperwords

