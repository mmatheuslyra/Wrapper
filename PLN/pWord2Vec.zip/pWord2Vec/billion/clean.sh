#!/bin/bash

rm -rf vectors.txt pWord2Vec.words*
